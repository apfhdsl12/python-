#bytes 데이터 전송시 encoding해서 전달
#bytes를 decoding을 해서 데이터 사용

# data = "Hi, I'm kyeong"

# encodedData = data.encode('utf-8')

# print(encodedData)

# decodedData = encodedData.decode('tuf-8')

# print(decodedData)

