#tuble

tub = ("abcd", 25,"address")

print(tub)

print(tub[0])

tub[0] = "aaa" #변경불가 (불변성)