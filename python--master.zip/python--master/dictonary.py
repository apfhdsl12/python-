
#딕셔너리 시작

# person = {
#     "name":"abcd",
#     "age" : 99,
#     "address" : "my home"
# }

# print(person)

# print(person["name"]) #딕셔너리 인덱싱

# person["name"] = "bbbb" #딕셔너리 값 변경

# print(person)


"""
딕셔너리 & 리스트
"""

                        #{},{} ,앞에는 하나의 아이템. 중요함!!!!
# data = [
#     {
#     "name":"a",
#     "level":1
#     },
#     {
#     "name":"b",
#     "level":2
#     }
# ]

# data[0]["level"] = 2
# data[1]["level"] = 2

# print(data)
