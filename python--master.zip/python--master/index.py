"""
변수
"""
age = 3 #integer
name = "abcd" #string
pie = 3.14 #float
isTrue = True #boolean
notYet = None #None
arr = [] #array
obj = {"name":"abcd"} #dictionary
tub = ("aaa,22") #tuble
col = {1,2,3,4,5,5,5,5} #set
data = b"Hi, I'm kyeong" #bytes


